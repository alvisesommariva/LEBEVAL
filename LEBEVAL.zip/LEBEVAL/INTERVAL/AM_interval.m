
function [AM,C]=AM_interval(deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg", on a unit-interval [-1,1].
% It is the set of Chebyshev points of degree "deg*m".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% AM : column vector of Chebyshev points ("deg*m+1" points);
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

deg_AM=m*deg;

% AM
k=1:deg_AM; k=k';
AM=cos((2*k-1)*pi/(2*deg_AM));

% AM constant
C=1/cos(pi/(2*m));
