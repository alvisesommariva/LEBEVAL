
function [lebconst,LB,UB,err,m,AM_card]=lebconst_eval_interval(deg,pts,tol)

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Domain: interval [-1,1].
%
% Evaluation of the Lebesgue constant "lebconst" of the set "pts", used for 
% interpolation, at degree "deg", lower-bound "LB" and upper bound "UB".
%--------------------------------------------------------------------------
% INPUT
%--------------------------------------------------------------------------
% deg: degree;
% pts: pointset on which Lebesgue constant is evaluated;
% tol: relative tolerance (do not choose it too low, say less than 10^(-3),
%      it may be time-consuming, especially at high degrees).
%--------------------------------------------------------------------------
% OUTPUT
%--------------------------------------------------------------------------
% lebconst: the Lebesgue constant of the set "pts", used for 
%           interpolation, at degree "deg", with weights "W";
% LB, UB  : lower-bound "LB" and upper bound "UB" of the Lebesgue constant;
% err     : relative error guaranteed;
% m       : factor used to determine the AM;
% AM_card : cardinality of the set used to determine the Lebesgue constant.
%--------------------------------------------------------------------------
% EXTERNAL ROUTINES
%--------------------------------------------------------------------------
% 1. AM_interval
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

if nargin < 3, tol=0.9*10^(-2); end

% compute "m"
Cpow=1; % C=(C_{cheb})^{Cpow}.
den=2*acos(1/(1+2*tol)^(1/Cpow));
m=ceil(pi/den);
err=((1/cos(pi/(2*m)))-1)/2;

% AM for estimating Lebesgue constant
[AM,C]=AM_interval(deg,m); AM_card=size(AM,1);

% Estimating Lebesgue constant
Vpts=chebpolys(deg,pts);
VAM=chebpolys(deg,AM);
LB=norm(Vpts'\VAM',1);
UB=C*LB;

% Estimated Lebesgue constant
lebconst=(LB+UB)/2;
