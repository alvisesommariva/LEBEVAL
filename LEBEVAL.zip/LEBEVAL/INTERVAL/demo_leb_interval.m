
function demo_leb_interval

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: interval "[-1,1]".
%
% 1. Determination of the following pointsets
%      a) Chebyshev
%      b) Legendre
%      c) Legendre-Lobatto
%      d) Equispaced
% 2. Evaluation of a certified Lebesgue constant on such a domain for
%    the pointsets above.
%
% The demo requires approximatively 2 seconds on a MacBook Pro with M1
% processor and 16GB of RAM.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

% settings
warning off;

diary on;
diary('numerical_experiments.txt')

degV=1:100;
m=3;

lebV=[]; lebVenh=[]; C=[];
pts_strC={'CH','LE','LL','EQ'};

for deg=degV
    [AM,CL]=AM_interval(deg,m);
    [AMH,CLH]=AM_interval(deg,4*m);
    C=[C; CL];
    for k=1:4
        switch k
            case 1
                % pts_str='Chebyshev';
                pts=pts_chebyshev(deg);
            case 2
                % pts_str='Legendre';
                pts=pts_legendre(deg);
            case 3
                % pts_str='Legendre-Lobatto';
                pts=pts_legendrelobatto(deg);
            case 4
                % pts_str='Equispaced';
                pts=linspace(-1,1,deg+1); pts=pts';
        end
        lebL(k)=leb_eval(deg,pts,AM);
        lebH(k)=leb_eval(deg,pts,AMH);
    end


    lebV=[lebV; lebL lebH];
    lebVenh=[lebVenh; ((1+CL)/2)*lebL ((1+CLH)/2)*lebH];

    fprintf('\n \t .....................................................');
    fprintf('\n \t Degree   : %3.0f',deg);
    fprintf('\n \t m        : %3.0f \n',m);
    fprintf('\n \t Card AM  : %3.0f',length(AM));
    fprintf('\n \t Card AMH : %3.0f \n',length(AMH));
    fprintf('\n \t RE L Est.: %1.1e',(CL-1)/2);
    fprintf('\n \t RE H Est.: %1.1e \n',(CLH-1)/2);

    print_lebconst('Chebyshev',lebL(1),lebH(1),CL,CLH);
    print_lebconst('Legendre',lebL(2),lebH(2),CL,CLH);
    print_lebconst('Leg.Lobatto',lebL(3),lebH(3),CL,CLH);
    print_lebconst('Equispaced',lebL(4),lebH(4),CL,CLH);
    fprintf('\n \t .....................................................');
    fprintf('\n')

end

diary off;

% Plots

% 1. All sets.

clear_figure(1); fig=figure(1);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV',lebVenh(:,2),'b-','LineWidth',4);
semilogy(degV',lebVenh(:,3),'c-.','LineWidth',4);
semilogy(degV',lebVenh(:,4),'m--','LineWidth',4);
legend(pts_strC{1},pts_strC{2},pts_strC{3},pts_strC{4},'Location','northwest');
grid on;
hold off;
print(fig,'leb_intv1','-depsc');
savefig('leb_intv1.fig');

% 2. "Best" sets.

clear_figure(2); fig=figure(2);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV',lebVenh(:,2),'b-','LineWidth',4);
semilogy(degV',lebVenh(:,3),'c-.','LineWidth',4);
legend(pts_strC{1},pts_strC{2},pts_strC{3},'Location','northwest');
grid on;
hold off;
print(fig,'leb_intv2','-depsc');
savefig('leb_intv2.fig');

diary off;








function print_lebconst(str,lebL,lebH,CL,CH)

fprintf('\n \t '); disp(str);
fprintf('\n \t Interval        : [%1.5e,%1.5e]',lebL(1),CL*lebL(1));
fprintf('\n \t Leb.Const.(low) : %1.5e',(1+CL)/2*lebL(1));
fprintf('\n \t Leb.Const.(high): %1.5e',(1+CH)/2*lebH(1));
relerr=abs((1+CH)/2*lebH(1)-(1+CL)/2*lebL(1))/abs((1+CL)/2*lebL(1));
fprintf('\n \t rel. error    : %1.5e',relerr);
if relerr > (CL-1)/2,
    fprintf(2,'\n \t Estimate not valid');
end
fprintf('\n');





function leb_constant=leb_eval(deg,pts,AM)

Vpts=chebpolys(deg,pts);
VAM=chebpolys(deg,AM);
leb_constant=norm(Vpts'\VAM',1);




function pts=pts_chebyshev(deg)

k=1:deg+1; k=k';
pts=cos((2*k-1)*pi/(2*(deg+1)));


function pts=pts_legendre(deg)

ab=r_jacobi(deg+1,0,0);
xw=gauss(deg+1,ab);
pts=xw(:,1);


function pts=pts_legendrelobatto(deg)

xw=lobatto_jacobi(deg-1,0,0);
pts=xw(:,1);



function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end