
function demo_basic

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Domain: simplex with vertices (0,0), (1,0), (0,1).
%
% This demo shows how to compute the Lebesgue constant at degree "deg" of 
% the interpolation at pointset "pts", weights "w", with a fixed tolerance.
%--------------------------------------------------------------------------
% EXAMPLE
%-------------------------------------------------------------------------- 
% >> demo_basic
% 
%  	 .....................................................
%  	 Degree:   5
%  	 Lebesgue constant approx  : 3.384762e+00
%  	 Lebesgue constant LB      : 3.355681e+00
%  	 Lebesgue constant UB      : 3.413843e+00
%  	 Required tolerance        : 1.000000e-02
%  	 Guaranteed tolerance      : 4.314480e-03
%  	 AM factor                 :        12
%  	 Test pointset cardinality :      3600
%  	 .....................................................
%
%-------------------------------------------------------------------------- 
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

deg=5;
tol=0.01;

% Choosing pointset: Waldron points.

pts=pts_waldron(deg);

% Approximate Lebesgue constant, bounds and some additional parameters.

[lebconst,LB,UB,err,m,AM_card]=lebconst_eval_simplex(deg,pts,tol);

% Statistics.

fprintf('\n \t .....................................................');
fprintf('\n \t Degree: %3.0f',deg);
fprintf('\n \t Lebesgue constant approx  : %1.6e',lebconst);
fprintf('\n \t Lebesgue constant LB      : %1.6e',LB);
fprintf('\n \t Lebesgue constant UB      : %1.6e',UB);
fprintf('\n \t Required tolerance        : %1.6e',tol);
fprintf('\n \t Guaranteed tolerance      : %1.6e',err);
fprintf('\n \t AM factor                 : %9.0f',m);
fprintf('\n \t Test pointset cardinality : %9.0f',AM_card);
fprintf('\n \t .....................................................');
fprintf('\n \n');
