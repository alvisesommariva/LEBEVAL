
function [AM,C]=AM_simplex2(deg,m,AM_type)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: simplex with vertices (0,0),(1,0),(0,1).
% 
% Computation of admissible mesh of degree "deg" (with a factor "m" that 
% must be larger than 1).
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% m: AM factor;
% AM_type:
%     1: D(C_{m n d}) and constant C,
%     2: D(C_{m n}) and constant C^d,
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% AM : matrix of multivariate points in cartesian coordinates (the k-th row
%      describes the k-th point);
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2014.
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Dimitri Jordan Kenne, Alvise  Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

if nargin < 3, AM_type=2; end

vertices=[0 0; 1 0; 0 1];

switch AM_type
    case 1 % tensorial low C
        d=2;
        [pts_hc,C_1D]=AM_square(deg,d*m,'[0,1]');
        AM=duffy_map(pts_hc,vertices);
        C=1/cos(pi/(2*m));

    otherwise % tensorial high C
        [pts_hc,C_1D]=AM_square(deg,m,'[0,1]');
        AM=duffy_map(pts_hc,vertices);
        C=C_1D^2;
end



function [AM,C]=AM_square(deg,m,option)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg", on a reference-square 
% domain, i.e.[-1,1] x [-1,1] or on [0,1] x [0,1] if "option=[0,1]".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% m: AM factor.
% option
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% AM : matrix of multivariate points in cartesian coordinates (the k-th row
%     describes the k-th point); it is an admissible mesh that is tensor
%     product of (deg*m+1) Chebyshev points in [-1,1];
% C  : AM constant over the domain (for the cube is the same of that of
%     (deg*m+1) Chebyshev points in [-1,1] at degree "deg").
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2014.
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Dimitri Jordan Kenne, Alvise  Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

if nargin < 3, option='[-1,1]'; end

[AM_1D,C_1D]=AM_interval(deg,m);

if strcmp(option,'[0,1]'), AM_1D=(AM_1D+1)/2; end

[AM1,AM2] = meshgrid(AM_1D);
AM=[AM1(:) AM2(:)];

C=C_1D;





function [AM,C]=AM_interval(deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg", on a unit-interval [-1,1].
% It is the set of Chebyshev points of degree "deg*m".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% AM : column vector of Chebyshev points ("deg*m+1" points);
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2014.
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Dimitri Jordan Kenne, Alvise  Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

deg_AM=m*deg;

% AM
k=1:deg_AM;
AM=cos((2*k-1)*pi/(2*deg_AM));

% AM constant
C=1/cos(pi/(2*m));









function pts=duffy_map(pts_hc,vertices)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine implements the Duffy-map also known as Proriol-map, from the
% square to a triangle defined by "vertices".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% pts_hc: matrix of N points in [-1,1]^2 in cartesian coordinates (the k-th
%     row describes the k-th point); it is a matrix of dimension "N x 2";
% vertices: 3 x 2 matrix, each row is a vertex.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% pts : matrix describing points in cartesian coordinates (the k-th row 
%       describes the k-th point).
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2014.
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Dimitri Jordan Kenne, Alvise  Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

X=pts_hc(:,1); Y=pts_hc(:,2);
pts_sim=[(1-X) X.*Y];

W=1-sum(pts_sim,2);
pts_sim_bar=[pts_sim W];
pts=pts_sim_bar*vertices;








