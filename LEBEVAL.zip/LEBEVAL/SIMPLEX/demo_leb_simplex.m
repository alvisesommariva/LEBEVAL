
function demo_leb_simplex

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Domain: simplex with vertices (0,0),(1,0),(0,1).
%
% 1. Determination of
%      a) Waldron points,
%      b) SALP set on the simplex (low Lebesgue constant, symmetric set),
%      c) ALP set on the simplex (low Lebesgue constant),
%      d) Simplex points.
%
% 2. Evaluation of a certified Lebesgue constant on such a domain for
%    the pointsets above.
%
% The demo requires approximatively 37 seconds on a MacBook Pro with M1
% processor, 8 cores and 16GB of RAM.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------


% Settings

degV=1:25;
m=4;

lebV=[]; lebVenh=[];
C=[];

pts_strC={'WALD','SALP','ALP','SIMP'};

diary on;
diary('numerical_experiments.txt');

for deg=degV
    [AM,CL]=AM_simplex2(deg,m);
    [AMH,CLH]=AM_simplex2(deg,4*m);
    C=[C; CL];
    for k=1:4
        switch k
            case 1
                %'WALD';
                pts=pts_waldron(deg);
            case 2
                if deg <= 18
                    %'SALP';
                    pts=pts_leb_symm_gll(deg);
                else
                    pts=[];
                end
            case 3
                if deg <= 18
                    %'ALP';
                    pts=pts_leb(deg);
                else
                    pts=[];
                end
            case 4
                %'SIMP';
                pts=pts_simplex(deg);
        end

        if (k == 1) |  (k == 2 & deg <= 18) |  (k == 3 & deg <= 18)  | ...
                (k == 4)
            lebL(k)=leb_eval(deg,pts,AM);
            lebH(k)=leb_eval(deg,pts,AMH);
            % RE(k)=abs(lebL(k)-lebH(k))/abs(lebH(k));
        end

    end

    lebV=[lebV; lebL lebH];
    lebVenh=[lebVenh; ((1+CL)/2)*lebL ((1+CLH)/2)*lebH];

    fprintf('\n \t .....................................................');
    fprintf('\n \t Degree   : %3.0f',deg);
    fprintf('\n \t m        : %3.0f \n',m);
    fprintf('\n \t Card AM  : %3.0f',length(AM));
    fprintf('\n \t Card AMH : %3.0f \n',length(AMH));
    fprintf('\n \t RE L Est.: %1.1e',(CL-1)/2);
    fprintf('\n \t RE H Est.: %1.1e \n',(CLH-1)/2);

    print_lebconst('Waldron',lebL(1),lebH(1),CL,CLH);
    print_lebconst('SALP   ',lebL(2),lebH(2),CL,CLH);
    print_lebconst('ALP    ',lebL(3),lebH(3),CL,CLH);
    print_lebconst('Simplex',lebL(4),lebH(4),CL,CLH);

    fprintf('\n \t .....................................................');
    fprintf('\n')

end

diary off;


% Plot.

% All sets.
clear_figure(1), fig=figure(1); 
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV',lebVenh(:,2),'b-','LineWidth',4);
semilogy(degV',lebVenh(:,3),'c-.','LineWidth',4);
semilogy(degV',lebVenh(:,4),'m--','LineWidth',4);
legend(pts_strC{1},pts_strC{2},pts_strC{3},pts_strC{4},...
    'Location','northwest');
grid on;
hold on;
print(fig,'leb_sim1.eps','-depsc');
savefig('leb_sim1.fig');

% "Best" sets.
clear_figure(2), fig=figure(2); 
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV',lebVenh(:,2),'b-','LineWidth',4);
semilogy(degV',lebVenh(:,3),'c-.','LineWidth',4);
legend(pts_strC{1},pts_strC{2},pts_strC{3},'Location','northwest')
grid on;
hold on;
print(fig,'leb_sim2.eps','-depsc');
savefig('leb_sim2.fig');









function leb_constant=leb_eval(deg,pts,AM)

Vpts=vandermonde_dubiner(deg,pts);
VAM=vandermonde_dubiner(deg,AM);
leb_constant=norm(Vpts'\VAM',1);





function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end




function print_lebconst(str,lebL,lebH,CL,CH)

fprintf('\n \t '); disp(str);
fprintf('\n \t interval      : [%1.5e,%1.5e]',lebL(1),CL*lebL(1));
fprintf('\n \t rough estimate: %1.5e',(1+CL)/2*lebL(1));
fprintf('\n \t finer estimate: %1.5e',(1+CH)/2*lebH(1));
relerr=abs((1+CH)/2*lebH(1)-(1+CL)/2*lebL(1))/abs((1+CL)/2*lebL(1));
fprintf('\n \t rel. error    : %1.5e',relerr);
if relerr > (CL-1)/2,
    fprintf(2,'\n \t Estimate not valid');
end
fprintf('\n');
