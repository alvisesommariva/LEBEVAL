
function demo_leb_cube

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: unit-cube "[-1,1]^3".
%
% 1. Extraction of
%      a) AFP (Approximate Fekete Points)
%      b) DLP (Discrete Leja Points)
%    on the domain.
%
% 2. Determination of a certified Lebesgue constant on such a domain for
%    AFP, DLP, first points in Haltonset belonging to the domain.
%
% 3. Lebesgue constants plot for degrees ranging from 1 to 15.
% 
% The demo requires approximatively 210 seconds on a MacBook Pro with M1 
% processor.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2014.
% Modified: November 21, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

% Settings
warning off;
diary on;
diary('numerical_experiments.txt');

degV=1:15;
m=3;


% Numerical experiments
lebV=[]; lebVenh=[];
C=[];

set_AFP={}; set_DLP={}; pts_str={'AFP','DLP','HAL'};

for deg=degV
    [AM,CL]=AM_cube(deg,m);
    C=[C; CL];
    for k=1:5
        switch k
            case 1
                % 'AFP';
                pts = dexsets_cube(deg,AM,0);
                set_AFP{end+1}=pts;
            case 2
                % 'DLP';
                pts = dexsets_cube(deg,AM,1);
                set_DLP{end+1}=pts;
            case 3
                % 'HAL';
                P = haltonset(3);
                dim=(deg+1)*(deg+2)*(deg+3)/6;
                X = net(P,10*dim);
                X=2*(X-0.5);
                dim=(deg+1)*(deg+2)*(deg+3)/6;
                pts=X(1:dim,:);
        end

        lebL(k)=wamleb(deg,pts,AM,[-1 -1 -1; 1 1 1]);

    end

    % statistics
        
    lebV=[lebV; lebL];
    lebVenh=[lebVenh; ((1+CL)/2)*lebL];

    fprintf('\n \t .....................................................');
    fprintf('\n \t Degree   : %3.0f',deg);
    fprintf('\n \t m        : %3.0f \n',m);
    fprintf('\n \t Card AM  : %3.0f',length(AM));
    fprintf('\n \t RE Est.: %1.1e \n',(CL-1)/2);

    print_lebconst3D('AFP',lebL(1),CL);
    print_lebconst3D('DLP',lebL(2),CL);
    print_lebconst3D('Halton',lebL(3),CL);

    fprintf('\n \t .....................................................');
    fprintf('\n')

end

diary off;

% Save pointsets.

saveset(degV,set_AFP,'set_AFP_cube.m');
saveset(degV,set_DLP,'set_DLP_cube.m');

% Plots

% 1. All sets.
clear_figure(1)
fig=figure(1);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV(:),lebVenh(:,2),'b--','LineWidth',4);
semilogy(degV',lebVenh(:,3),'c-.','LineWidth',4);
legend(pts_str{1},pts_str{2},pts_str{3},'Location','northwest');
grid on;
hold on;
print(fig,'leb_cube1','-depsc');
savefig('leb_cube1.fig');

% 2. Best sets.
clear_figure(2)
fig=figure(2);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV(:),lebVenh(:,2),'b--','LineWidth',4);
legend(pts_str{1},pts_str{2},'Location','northwest');
grid on;
hold on;
print(fig,'leb_cube2','-depsc');
savefig('leb_cube2.fig');





function print_lebconst3D(str,lebL,CL)

fprintf('\n \t '); disp(str);
fprintf('\n \t Interval      : [%1.5e,%1.5e]',lebL(1),CL*lebL(1));
fprintf('\n \t Leb.constant  : %1.5e',(1+CL)/2*lebL(1));
fprintf('\n');





function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end
