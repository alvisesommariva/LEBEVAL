
function DOP = wamdopeval(deg,R1,R2,pts,dbox,domain)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% The routine computes the Vandermonde matrix of degree deg at the points 
% "pts" in a discrete orthogonal polynomial basis, depending on "R1" and 
% "R2".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% R1, R2: matrices of change of basis, w.r.t a certain shifted monomial 
%    basis;
% pts: interpolation/least square points;
% dbox: variable that defines the smallest hyperectangle with sides
%     parallel to the axis, containing the domain.
%     If "dbox" is not provided, it defines the smaller "hyperrectangle", 
%     with sides parallel to the cartesian axes, containing the pointset 
%     "X". 
%     It is a matrix with dimension "2 x d", where "d" is the dimension  
%     of the space in which it is embedded the domain. 
%     For instance, for a 2-sphere, it is "d=3", while for a 2 dimensional
%     polygon it is "d=2".
%     As example, the set "[-1,1] x [0,1]" is described as "[-1 0; 1 1]".
%%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% DOP: a generalized Vandermonde matrix w.r.t. discrete orthogonal 
%      polynomials of degree "deg" evaluated at "pts".
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014,
% Adapted to complex case: October 2023,
% Modified: November 13, 2023.
%--------------------------------------------------------------------------

W=dCHEBVAND(deg,pts,dbox);
DOP=(W/R1)/R2;

