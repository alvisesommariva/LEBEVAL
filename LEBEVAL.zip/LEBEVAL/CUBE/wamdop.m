
function [Q,R1,R2] = wamdop(deg,pts,dbox)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine computes discrete orthogonal polynomials up to degree "deg:
% on the mesh (e.g. a AM or a WAM): 
% a) Q is the corresponding orthogonal matrix,
% b) inv(R1)*inv(R2) the orthogonalization matrix.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% pts: interpolation/least square points;
% dbox: variable that defines the smallest hyperectangle with sides
%     parallel to the axis, containing the domain.
%     If "dbox" is not provided, it defines the smaller "hyperrectangle", 
%     with sides parallel to the cartesian axes, containing the pointset 
%     "X". 
%     It is a matrix with dimension "2 x d", where "d" is the dimension  
%     of the space in which it is embedded the domain. 
%     For instance, for a 2-sphere, it is "d=3", while for a 2 dimensional
%     polygon it is "d=2".
%     As example, the set "[-1,1] x [0,1]" is described as "[-1 0; 1 1]".
%%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% Q: generalized Vandermonde matrix w.r.t. discrete orthogonal polynomials
%    of degree "deg".
% R1, R2: matrices of change of basis, w.r.t a certain shifted monomial 
%    basis.
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014
% Adapted to complex case: October 2023
% Modified: November 13, 2023.
%--------------------------------------------------------------------------

V=dCHEBVAND(deg,pts,dbox);
[Q1,R1]=qr(V,0);
[Q,R2]=qr(V/R1,0);
