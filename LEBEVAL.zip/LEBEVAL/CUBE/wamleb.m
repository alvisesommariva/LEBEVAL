function leb = wamleb(deg,wam,cmesh,dbox)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Routine that computes the Lebesgue constant at degree "deg" of least-
% squares polynomial fitting on "pts", using the control mesh "cmesh".
%
% Domains are bivariate or trivariate.
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova.
% Written: October 2014;
% Modified: November 21, 2023.
%--------------------------------------------------------------------------

if nargin < 4, dbox=[]; end

if isempty(dbox)
    both=[wam;cmesh];
    dbox(1,1)=min(both(:,1));
    dbox(1,2)=min(both(:,2));
    dbox(2,1)=max(both(:,1));
    dbox(2,2)=max(both(:,2));
    if length(both(1,:)) == 3
        dbox(1,3)=min(both(:,3));
        dbox(2,3)=max(both(:,3));
    end
end

[Q,R1,R2]=wamdop(deg,wam,dbox);
DOP=wamdopeval(deg,R1,R2,cmesh,dbox);
leb=norm(Q*DOP',1);