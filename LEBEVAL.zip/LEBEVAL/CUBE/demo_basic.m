
function demo_basic

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Domain: unit-cube [-1,1]^3.
%
% This demo shows how to compute the Lebesgue constant at degree "deg" of 
% interpolation at pointset "pts", weights "w", with a fixed tolerance.
%--------------------------------------------------------------------------
% EXAMPLE
%-------------------------------------------------------------------------- 
% >> demo_basic
% 
%  	 .....................................................
%  	 Degree:   5
%  	 Lebesgue constant approx  : 6.611786e+00
%  	 Lebesgue constant LB      : 6.137081e+00
%  	 Lebesgue constant UB      : 7.086491e+00
%  	 Required tolerance        : 8.000000e-02
%  	 Guaranteed tolerance      : 7.735027e-02
%  	 AM factor                 :         3
%  	 Test pointset cardinality :      3375
%  	 .....................................................
%
%-------------------------------------------------------------------------- 
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

deg=5;
tol=0.08;

% The pointset corresponds with an AM at degree 10 ("m" factor equal to 4).
% Weights are set equal to 1.

pts=AM_cube(10,4);

% Approximate Lebesgue constant, bounds and some additional parameters.
[lebconst,LB,UB,err,m,AM_card]=lebconst_eval_cube(deg,pts,tol);

% Statistics.

fprintf('\n \t .....................................................');
fprintf('\n \t Degree: %3.0f',deg);
fprintf('\n \t Lebesgue constant approx  : %1.6e',lebconst);
fprintf('\n \t Lebesgue constant LB      : %1.6e',LB);
fprintf('\n \t Lebesgue constant UB      : %1.6e',UB);
fprintf('\n \t Required tolerance        : %1.6e',tol);
fprintf('\n \t Guaranteed tolerance      : %1.6e',err);
fprintf('\n \t AM factor                 : %9.0f',m);
fprintf('\n \t Test pointset cardinality : %9.0f',AM_card);
fprintf('\n \t .....................................................');
fprintf('\n \n');
