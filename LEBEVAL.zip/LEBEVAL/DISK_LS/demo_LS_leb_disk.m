
function demo_LS_leb_disk

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: unit-disk "B((0,0),1)".
%
% 1. Definition of  
%    a) a set with 12000 Halton points,
%    b) a mesh given with AM of degree "20" on the domain,
%    c) definition of least-square weight for both,
%    d) compression at degree "deg" for both rules,
%    e) definition of hyperinterpolant.
%
% 2. Determination of a certified Lebesgue constant on such a domain for
%    these least-squares operators.
%
% 3. Lebesgue constants plot for degrees ranging from 1 to 20.
% 
% The demo requires approximatively 910 seconds on a MacBook Pro with M1 
% processor.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

warning off;
diary on;
diary('numerical_experiments.txt');

% Settings
degV=1:20;
m=4;
card_halton=12800;
tol=10^(-14); nest=1; comp_type=2;

fid=fopen('leb_file.txt','w+');

%-------------------------- Numerical experiments -------------------------

lebV=[]; lebVenh=[]; C=[];

% HALTON SET
P = haltonset(2);
X = net(P,10*card_halton); X=2*(X-0.5);
iD=find( (X(:,1)).^2 + (X(:,2)).^2 <= 1 );
ind=iD(1:card_halton);
XD=X(ind,:); WD=pi*ones(card_halton,1)/card_halton;

% AM 
XC=AM_disk(20,4); WC=ones(size(XC,1),1);

pts_str={'HAL','AM20','HALC','AM20C','HYP'};

for deg=degV

    % AM ON THE DISK
    [AM,CL]=AM_disk(deg,m);
    C(end+1)=CL;

    % LS-HALTON, LEBESGUE CONSTANT.
    lebV(end+1,1)=LS_lebesgue(deg,XD,WD,AM);

    % LS-AM, LEBESGUE CONSTANT.
    lebV(end,2)=LS_lebesgue(deg,XC,WC,AM);

    % LS-HALTON COMPRESSED, LEBESGUE CONSTANT.
    [T,w,res,mom]=cqmc_01(2*deg,XD,tol,nest,comp_type);
    lebV(end,3)=LS_lebesgue(deg,T,w,AM);

    % LS-AM COMPRESSED, LEBESGUE CONSTANT.
    [XCC,WCC,momerr]=comprexcub(2*deg,XC,WC,1);
    % [XCC,WCC,res,mom]=cqmc_01(2*deg,XC,tol,nest,comp_type);
    lebV(end,4)=LS_lebesgue(deg,XCC,WCC,AM);

    % HYPERINTERPOLATION.
    xw=cub_disk(2*deg);
    XH=xw(:,1:2); WH=xw(:,3);
    lebV(end,5)=LS_lebesgue(deg,XH,WH,AM);

    lebVenh=[lebVenh; ((1+CL)/2)*lebV(end,:)];

    fprintf('\n \t .....................................................');
    fprintf('\n \t Domain       : UNIT DISK B((0,0),1)');
    fprintf('\n \t Degree       : %3.0f',deg);
    fprintf('\n \t m            : %3.0f \n',m);

    fprintf('\n \t ... Cardinalities of pointsets: \n ');
    fprintf('\n \t AM(Leb.const): %3.0f \n',length(AM));
    fprintf('\n \t HAL          : %6.0f',length(WD));
    fprintf('\n \t AM-LS        : %6.0f',length(WC));
    fprintf('\n \t HALC         : %6.0f',length(w));
    fprintf('\n \t AMC-LS       : %6.0f',length(WCC));
    fprintf('\n \t HYP          : %6.0f',length(WH));
    fprintf('\n \n \t res HCMP     : %1.1e',res(end));
    fprintf('\n \t momerr AMC-LS: %1.1e',momerr);
    fprintf('\n \t RE Est.      : %1.1e \n',(CL-1)/2);

    fprintf('\n \t ... Lebesgue constants: \n ');

    print_lebconst_short('LS-HALTON',lebV(end,1),CL);
    print_lebconst_short('LS-AM',lebV(end,2),CL);
    print_lebconst_short('LS-HALTON COMPRESSED',lebV(end,3),CL);
    print_lebconst_short('LS-AM COMPRESSED',lebV(end,4),CL);
    print_lebconst_short('HYPERINTERPOLATION',lebV(end,5),CL);

    fprintf('\n \t .....................................................');
    fprintf('\n')


    fprintf(fid,'\n \t %1.3e %1.3e %1.3e %1.3e %1.3e',lebVenh(end,1),...
        lebVenh(end,2),lebVenh(end,3),lebVenh(end,4),lebVenh(end,5));
end

diary off;

clear_figure(1)
fig=figure(1);
semilogy(degV',lebVenh(:,1),'r-','LineWidth',4);
hold on;
semilogy(degV(:),lebVenh(:,2),'b-','LineWidth',4);
semilogy(degV(:),lebVenh(:,3),'r:','LineWidth',4);
semilogy(degV(:),lebVenh(:,4),'b:','LineWidth',4);
semilogy(degV(:),lebVenh(:,5),'c-','LineWidth',4);
% legend(pts_str{1},pts_str{2},pts_str{3},pts_str{4},'Location','northwest');
legend(pts_str{1},pts_str{2},pts_str{3},pts_str{4},pts_str{5},...
    'Location','northwest');
grid on;
hold on;
print(fig,'leb_LS_disk1','-depsc');
savefig('leb_LS_disk1.fig');

clear_figure(2)
fig=figure(2);
semilogy(degV(:),lebVenh(:,2),'b-','LineWidth',4);
hold on;
semilogy(degV(:),lebVenh(:,4),'b:','LineWidth',4);
semilogy(degV(:),lebVenh(:,5),'c-','LineWidth',4);
% legend(pts_str{1},pts_str{2},pts_str{3},pts_str{4},'Location','northwest');
legend(pts_str{2},pts_str{4},pts_str{5},'Location','northwest');
grid on;
hold on;
print(fig,'leb_LS_disk2','-depsc');
savefig('leb_LS_disk2.fig');


s=fclose(fid);





function leb=LS_lebesgue(deg,pts,W,AM)

Vpts=vandermonde_logan_shepp(deg,pts);
diagW=diag(W);
sqrtW=sqrt(W);
diag_sqrtW=diag(sqrtW);
[Q,R]=qr(diag_sqrtW*Vpts,0);
VAM=vandermonde_logan_shepp(deg,AM);
argMAT=(VAM/R)*Q'*diag_sqrtW;
leb=norm(argMAT,inf);


function print_lebconst_short(str,lebL,CL)

fprintf('\n \t '); disp(str);
fprintf('\n \t Interval      : [%1.5e,%1.5e]',lebL(1),CL*lebL(1));
fprintf('\n \t Leb. constant : %1.5e',(1+CL)/2*lebL(1));
fprintf('\n');

function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end


