
function demo_leb_square

%--------------------------------------------------------------------------
% OBJECT
%--------------------------------------------------------------------------
% Domain: square "[-1,1]^2".
%
% 1. Determination of
%      a) Padua points,
%      b) Morrow-Patterson points (even degrees),
%      c) Halton pointset (subset).
%
% 2. Evaluation of a certified Lebesgue constant on such a domain for
%    the pointsets above.
%
% The demo requires approximatively 9 seconds on a MacBook Pro with M1
% processor, 8 cores and 16GB of RAM.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

% Settings

degV=1:25;
m=3;

lebV=[]; lebVenh=[];
C=[];

pts_strC={'PD','MP','HAL'};

diary on;
diary('numerical_experiments.txt');

for deg=degV
    [AM,CL]=AM_square(deg,m);
    [AMH,CLH]=AM_square(deg,4*m);
    C=[C; CL];
    for k=1:4
        switch k
            case 1
                pts_str_sh{k}='PD';
                pts=pts_padua(deg);

            case 2
                pts_str_sh{k}='MP';
                if (rem(deg,2) == 0)
                    pts=pts_morrowpatterson(deg);
                else
                    pts=[];
                end

            case 3
                pts_str_sh{k}='HAL';
                P = haltonset(2);
                X = net(P,(deg+1)*(deg+2)/2);
                pts=2*(X-0.5);
        end


        if (k == 1) | (k == 2 & (rem(deg,2) == 0)) | (k == 3)
            lebL(k)=leb_eval(deg,pts,AM);
            lebH(k)=leb_eval(deg,pts,AMH);
            RE(k)=abs(lebL(k)-lebH(k))/abs(lebH(k));
        else
            lebL(k)=NaN;
            lebH(k)=NaN;
            RE(k)=NaN;
        end

    end

    lebV=[lebV; lebL lebH];
    lebVenh=[lebVenh; ((1+CL)/2)*lebL ((1+CLH)/2)*lebH];

    fprintf('\n \t .....................................................');
    fprintf('\n \t Degree   : %3.0f',deg);
    fprintf('\n \t m        : %3.0f \n',m);
    fprintf('\n \t Card AM  : %3.0f',length(AM));
    fprintf('\n \t Card AMH : %3.0f \n',length(AMH));
    fprintf('\n \t RE L Est.: %1.1e',(CL-1)/2);
    fprintf('\n \t RE H Est.: %1.1e \n',(CLH-1)/2);

    print_lebconst('Padua',lebL(1),lebH(1),CL,CLH);
    print_lebconst('Morrow-Patterson',lebL(2),lebH(2),CL,CLH);
    print_lebconst('Halton',lebL(3),lebH(3),CL,CLH);

    fprintf('\n \t .....................................................');
    fprintf('\n')

end

diary off;

% Plots

% 1. All sets.
clear_figure(1)
fig=figure(1);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
iMP=find(rem(degV,2) == 0);
semilogy(degV(iMP),lebVenh(iMP,2),'bo','LineWidth',4);
semilogy(degV',lebVenh(:,3),'c-.','LineWidth',4);
legend(pts_str_sh{1},pts_str_sh{2},pts_str_sh{3},'Location','northwest');
grid on;
hold on;
print(fig,'leb_sq1.eps','-depsc');
savefig('leb_sq1.fig');

% "Best" sets.
clear_figure(2);
fig=figure(2);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
iMP=find(rem(degV,2) == 0);
semilogy(degV(iMP),lebVenh(iMP,2),'bo','LineWidth',4);
legend(pts_str_sh{1},pts_str_sh{2},'Location','northwest');
grid on;
hold on;
print(fig,'leb_sq2.eps','-depsc');
savefig('leb_sq2.fig');





function leb_constant=leb_eval(deg,pts,AM)

dbox=[-1 -1; 1 1];

if isempty(pts), error('pts is empty in leb_eval'); end

Vpts=dCHEBVAND(deg,pts,dbox);
VAM=dCHEBVAND(deg,AM,dbox);
leb_constant=norm(Vpts'\VAM',1);

cond_pts=cond(Vpts);
% if  cond_pts > 10^6
%     fprintf('\n \t Cond. Vandermonde matrix at pts: %1.3e',cond_pts);
% end





function print_lebconst(str,lebL,lebH,CL,CH)

if strcmp(str,'Morrow-Patterson') & isnan(lebL), return; end

fprintf('\n \t '); disp(str);
fprintf('\n \t interval      : [%1.5e,%1.5e]',lebL(1),CL*lebL(1));
fprintf('\n \t rough estimate: %1.5e',(1+CL)/2*lebL(1));
fprintf('\n \t finer estimate: %1.5e',(1+CH)/2*lebH(1));
relerr=abs((1+CH)/2*lebH(1)-(1+CL)/2*lebL(1))/abs((1+CL)/2*lebL(1));
fprintf('\n \t rel. error    : %1.5e',relerr);
if relerr > (CL-1)/2,
    fprintf(2,'\n \t Estimate not valid');
end
fprintf('\n');





function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end
