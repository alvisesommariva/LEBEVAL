
function [AM,C]=AM_square(deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: square "[-1,1]^2".
% 
% Computation of admissible mesh of degree "deg" (with a factor "m" that 
% must be larger than 1).
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% m: AM factor (strictly larger than 1).
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% AM : matrix of multivariate points in cartesian coordinates (the k-th row
%      describes the k-th point);
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on November 22, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise 
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% L. Leokadia Białas-Cież, 
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 22, 2023
%--------------------------------------------------------------------------

[AM_1D,C_1D]=AM_interval(deg,m);

[AM1,AM2] = meshgrid(AM_1D);
AM=[AM1(:) AM2(:)];

C=C_1D;





function [AM,C]=AM_interval(deg,m)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Building AM(deg) using a mesh of degree "deg", on a unit-interval [-1,1].
% It is the set of Chebyshev points of degree "deg*m".
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% m: AM factor.
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% AM : column vector of Chebyshev points ("deg*m+1" points);
% C  : AM constant over the domain.
%--------------------------------------------------------------------------
% DATES:
%--------------------------------------------------------------------------
% Written on October 6, 2023 (by A. Sommariva).
% Modified on November 9, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

deg_AM=m*deg;

% AM
k=1:deg_AM;
AM=cos((2*k-1)*pi/(2*deg_AM));

% AM constant
C=1/cos(pi/(2*m));






