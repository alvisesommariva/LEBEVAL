
function pts=pts_morrowpatterson(deg)

%--------------------------------------------------------------------------
% Object:
%--------------------------------------------------------------------------
% Morrow-Patterson points of degree "deg" (on the square [-1,1]x[-1,1]).
% Working for "dim=2".
%
%               IMPORTANT: the degree must be even!
%--------------------------------------------------------------------------
% Input:
%--------------------------------------------------------------------------
% deg: degree of the pointset,
%--------------------------------------------------------------------------
% Output:
%--------------------------------------------------------------------------
% pts: Morrow-Patterson points of degree "deg".
%--------------------------------------------------------------------------
% Dates:
%--------------------------------------------------------------------------
% Written on November 9, 2023 (by A. Sommariva).
% Modified on November 9, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------

if rem(deg,2) > 0, error('Degree is not an even positive integer'); end

% Column vector to determine abscissae.
m=1:(deg+1); m=m';
xMP=cos(m*pi/(deg+2));

% Column vectors to determine ordinates.
k=1:(deg/2)+1; k=k';
yMP_oddM=cos(2*k*pi/(deg+3));
yMP_evenM=cos((2*k-1)*pi/(deg+3));

% Assembling pointset
pts=[];
for m=1:(deg+1)
    if rem(m,2) == 1
        ptsLy=yMP_oddM;
    else
        ptsLy=yMP_evenM;
    end
    ptsLx=xMP(m)*ones(size(ptsLy));
    ptsL=[ptsLx ptsLy];
    pts=[pts; ptsL];
end






