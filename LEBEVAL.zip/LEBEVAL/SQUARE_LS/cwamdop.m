
function [Q,R1,R2] = cwamdop(deg,pts,domain)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% computes discrete orthogonal polynomials up to degree deg
% on the mesh wam: Q is the corresponding orthogonal matrix,
% inv(R1)*inv(R2) the orthogonalization matrix.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% pts: interpolation/least square points;
% domain: domain structure (dependent on the domain, see "define_domain.m").
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% Q: generalized Vandermonde matrix w.r.t. discrete orthogonal polynomials
%    of degree "deg".
% R1, R2: matrices of change of basis, w.r.t a certain shifted monomial 
%    basis.
%--------------------------------------------------------------------------
% DATA:
%--------------------------------------------------------------------------
% Authors: Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014
% Adapted to complex case: October 2023
% Modified: November 7, 2023.
%--------------------------------------------------------------------------

V=gen_vandermonde_matrix(pts,deg,domain.zC,domain.zR);
[Q1,R1]=qr(V,0);
[Q,R2]=qr(V/R1,0);