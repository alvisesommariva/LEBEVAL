
function fek = dexsets_ball(deg,AM,leja)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: unit-ball "B((0,0,0),1)".
%
% Extraction of discrete extremal sets, namely approximate Fekete or Leja
% interpolation points, from a 3D weakly-admissible mesh (wam) or 
% admissible mesh (AM) on the domain.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% AM : 3-column array of mesh points coordinates, from which the
%      approximate Fekete or Leja points will be extracted;
% leja: parameter that choosed the discrete extremal set:
%          leja=0: computes approximate Fekete points
%          leja=1: computes approximate Leja points
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% fek:  3-column array of approximate Fekete or Leja points coordinates.
%--------------------------------------------------------------------------
% AUTHORS:
%--------------------------------------------------------------------------
% Alvise Sommariva and Marco Vianello, University of Padova
% Written: October 2014.
% Modified: November 2023 (adapted to this domain)
%--------------------------------------------------------------------------

dbox=[-1 -1 -1; 1 1 1];

VAM=dCHEBVAND(deg,AM,dbox);

% extracting the interpolation points
dim=(deg+1)*(deg+2)*(deg+3)/6;

if leja == 0
    % approximate Fekete points and corresponding weights
    % by QR factorization with column pivoting of Q'
    w=VAM'\ones(dim,1);
    ind=find(abs(w)>0);
    fek=AM(ind,:);
else
    % approximate Leja points and corresponding weights
    % by LU factorization with row pivoting of Q
    [L,U,perm]=lu(VAM,'vector');
    fek=AM(perm(1:dim),:);
end


