
function demo_leb_ball

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: unit-ball "B((0,0,0),1)".
% 
% 1. Extraction of 
%      a) AFP (Approximate Fekete Points)
%      b) DLP (Discrete Leja Points)
%    on the domain.
% 2. Determination of a certified Lebesgue constant on such a domain for 
%    AFP, DLP, first points in Haltonset belonging to the domain.
% 3. Lebesgue constants plot.
%
% The demo requires approximatively 150 seconds on a MacBook Pro with M1 
% processor.
%--------------------------------------------------------------------------
% AUTHORS
%--------------------------------------------------------------------------
% Authors: Dimitri J. Kenne, Alvise Sommariva and Marco Vianello.
% Written: October 2023
% Modified: November 22, 2023.
%
% Acknowledgements: 
% The authors thank Leokadia Białas-Cież for her precious help.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright(C) 2023 Dimitri Jordan Kenne, Alvise Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:
%
% D.J. Kenne <dimitri.kenne@doctoral.uj.edu.pl>
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>
%
% Date: November 22, 2023
%--------------------------------------------------------------------------


% Settings.
warning off;
diary on;
diary('numerical_experiments.txt');

degV=1:10;
m=5;


% Numerical experiments
lebV=[];  lebVenh=[];
C=[];

set_AFP={}; set_DLP={}; pts_str={'AFP','DLP','HAL'};

for deg=degV
    [AM,CL]=AM_ball(deg,m);
    C=[C; CL];
    for k=1:5
        switch k
            case 1
                % 'AFP';
                pts = dexsets_ball(deg,AM,0);
                set_AFP{end+1}=pts;
            case 2
                % 'DLP';
                pts = dexsets_ball(deg,AM,1);
                set_DLP{end+1}=pts;
            case 3
                % 'HAL';
                P = haltonset(3);
                dim=(deg+1)*(deg+2)*(deg+3)/6;
                X = net(P,10*dim);
                iXD=find( (X(:,1)).^2+(X(:,2)).^2+(X(:,3)).^2 <= 1);
                dim=(deg+1)*(deg+2)*(deg+3)/6;
                pts=X(iXD(1:dim),:);
        end

        lebL(k)=wamleb(deg,pts,AM,[-1 -1 -1; 1 1 1]);

    end

    lebV=[lebV; lebL];
    lebVenh=[lebVenh; (1+CL)*lebL/2];

    % Statistics.

    fprintf('\n \t .....................................................');
    fprintf('\n \t Degree   : %3.0f \n',deg);
    fprintf('\n \t Card AM  : %3.0f',length(AM));
    fprintf('\n \t RE Est.: %1.1e \n',(CL-1)/2);

    fprintf('\n \n \t Lebesgue constants \n');
    print_lebconst3D('AFP',lebL(1),CL);
    print_lebconst3D('DLP',lebL(2),CL);
    print_lebconst3D('HALTON',lebL(3),CL);
    fprintf('\n \t .....................................................');
    fprintf('\n')

end


% Save pointsets.

saveset(degV,set_AFP,'set_AFP_ball.m');
saveset(degV,set_DLP,'set_DLP_ball.m');


% Plots

% 1. All sets.
clear_figure(1)
fig=figure(1);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV',lebVenh(:,2),'b--','LineWidth',4);
semilogy(degV',lebVenh(:,3),'c-.','LineWidth',4);
legend(pts_str{1},pts_str{2},pts_str{3},'Location','northwest');
grid on;
hold on;
print(fig,'leb_ball1','-depsc');
savefig('leb_ball1.fig');

% 2. Best sets.
clear_figure(2)
fig=figure(2);
semilogy(degV',lebVenh(:,1),'r:','LineWidth',4);
hold on;
semilogy(degV',lebVenh(:,2),'b--','LineWidth',4);
legend(pts_str{1},pts_str{2},'Location','northwest');
grid on;
hold on;
print(fig,'leb_ball2','-depsc');
savefig('leb_ball2.fig');









% Attached routines.

function clear_figure(nfig)

h=figure(nfig);
f_nfig=ishandle(h)&&strcmp(get(h,'type'),'figure');
if f_nfig,
    clf(nfig);
end



function print_lebconst3D(str,lebL,CL)

fprintf('\n \t '); disp(str);
fprintf('\n \t Interval      : [%1.5e,%1.5e]',lebL(1),CL*lebL(1));
fprintf('\n \t Leb.constant  : %1.5e',(1+CL)/2*lebL(1));
fprintf('\n');