
function saveset(degV,set_AFP,filename)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% This routine saves on "filename" the pointsets described by 
% a) the vector of degrees "degV";
% b) the cell "set_AFP" in which "set_AFP{k}" is the pointset for degree
%    degV(k);
%--------------------------------------------------------------------------

fid=fopen(filename,'w+');

namefunction=extractBefore(filename,'.m');

fprintf(fid,'\n \t');  fprintf(fid,['function pts=',namefunction,'(deg)']);
fprintf(fid,'\n \n');
fprintf(fid,'\n \t switch deg');

for j=1:length(degV)
    deg=degV(j);
    fprintf(fid,'\n \n \t case %3.0f',deg);
    pts=set_AFP{j};
    fprintf(fid,'\n \t pts=[');
    for j=1:size(pts,1)
       fprintf(fid,'\n \t');
       fprintf(fid,'%1.15e  %1.15e',pts(j,1),pts(j,2));
    end
    fprintf(fid,'\n \t ];');
end

fprintf(fid,'\n \n \t end \n \n');

fid_close=fclose(fid);



