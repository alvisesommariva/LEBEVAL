
function fek = dexsets_disk(deg,AM,leja)

%--------------------------------------------------------------------------
% OBJECT:
%--------------------------------------------------------------------------
% Domain: unit-disk "B((0,0),1)".
%
% Extraction of discrete extremal sets, namely approximate Fekete or Leja
% interpolation points, from a 2D weakly-admissible mesh (wam) or 
% admissible mesh (AM) on the domain.
%--------------------------------------------------------------------------
% INPUT:
%--------------------------------------------------------------------------
% deg: interpolation degree;
% AM : 2-column array of mesh points coordinates, from which the
%      approximate Fekete or Leja points will be extracted;
% leja: parameter that choosed the discrete extremal set:
%          leja=0: computes approximate Fekete points
%          leja=1: computes approximate Leja points
%--------------------------------------------------------------------------
% OUTPUT:
%--------------------------------------------------------------------------
% fek:  2-column array of approximate Fekete or Leja points coordinates.
%--------------------------------------------------------------------------
% Adapted
%--------------------------------------------------------------------------
% Written on October 2014 (by A. Sommariva and M. Vianello).
% Modified on November 21, 2023 (by A. Sommariva).
% Authors: L. Leokadia Białas-Cież, D.J. Kenne, A. Sommariva, M. Vianello.
%--------------------------------------------------------------------------
% LICENSE
%--------------------------------------------------------------------------
% Copyright (C) 2023 Leokadia Białas-Cież, Dimitri Jordan Kenne, Alvise 
% Sommariva, Marco Vianello.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation; either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program; if not, write to the Free Software
% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%
% Authors:  
%
% L. Leokadia Białas-Cież, 
% D.J. Kenne
% Alvise Sommariva <alvise@math.unipd.it>
% Marco Vianello   <marcov@math.unipd.it>       
%
% Date: November 21, 2023
%--------------------------------------------------------------------------


VAM=vandermonde_logan_shepp(deg,AM);

% extracting the interpolation points
dim=(deg+1)*(deg+2)/2;

if leja == 0
    % approximate Fekete points and corresponding weights
    % by QR factorization with column pivoting of Q'
    w=VAM'\ones(dim,1);
    ind=find(abs(w)>0);
    fek=AM(ind,:);
else
    % approximate Leja points and corresponding weights
    % by LU factorization with row pivoting of Q
    [L,U,perm]=lu(VAM,'vector');
    fek=AM(perm(1:dim),:);
end


